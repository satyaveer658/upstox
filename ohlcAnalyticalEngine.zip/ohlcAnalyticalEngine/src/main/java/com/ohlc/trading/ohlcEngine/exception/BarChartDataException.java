package com.ohlc.trading.ohlcEngine.exception;

public class BarChartDataException extends RuntimeException{

    public BarChartDataException(String message) {
        super(message);
    }
}
