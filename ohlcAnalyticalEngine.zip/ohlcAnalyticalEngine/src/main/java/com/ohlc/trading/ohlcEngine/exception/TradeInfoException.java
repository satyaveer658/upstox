package com.ohlc.trading.ohlcEngine.exception;

public class TradeInfoException extends RuntimeException{

    public TradeInfoException(String message) {
        super(message);
    }
}
