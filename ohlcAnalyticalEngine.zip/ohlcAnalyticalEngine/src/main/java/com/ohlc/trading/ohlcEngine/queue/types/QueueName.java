package com.ohlc.trading.ohlcEngine.queue.types;

public class QueueName {
    public static final String FSM_Q = "FSM_Q";
    public static final String CHART_Q = "CHART_Q";
}
