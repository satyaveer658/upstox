package com.ohlc.trading.ohlcEngine.states;

public enum State {
    ACTIVE,
    INACTIVE
}
