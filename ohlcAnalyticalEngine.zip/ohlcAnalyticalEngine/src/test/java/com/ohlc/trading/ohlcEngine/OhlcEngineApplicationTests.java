package com.ohlc.trading.ohlcEngine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OhlcEngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
