## Tech Requirements

For building and running the application you need:

- [JDK 1.8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
- [Maven 3](https://maven.apache.org)

## Running the application through WorkerReaderImplTest.java 

Since the dataset is larger all the records cannot be displayed in IDE console due to buffer size limitation, hence for simplicity the end-to-end logs are appended to external "${LOGS}/ohlc-logger.log" file under following location "ohlcEngine/logs/*" this folder and files will be generated once is started. 


## Running the application locally [Currently dont use this method]

There are several ways to run a Spring Boot application on your local machine. One way is to execute the main method in the "com.ohlc.trading.ohlcEngine.OHLCEngineApplication" class from your IDE.

Alternatively you can use the [Spring Boot Maven plugin](https://docs.spring.io/spring-boot/docs/current/reference/html/build-tool-plugins-maven-plugin.html) like so:

`````shell
mvn spring-boot:run
`````

## Deploying the application to Pivotal Cloud Foundry

The easiest way to deploy the sample application to Cloud Foundry is to use the [cf CLI](https://github.com/cloudfoundry/cli):

`````shell
cf push manifest.yml 
`````

This will do following things:

* Upload a droplet on CF.
* An app with name from manifest will be created on CF
* Service called "ohlcEngine"

## System Design

![alt text](/ohlcAnalyticalEngine/blob/SystemDesign.PNG)

